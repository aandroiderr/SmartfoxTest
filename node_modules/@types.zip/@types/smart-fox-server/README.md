# Installation
> `npm install --save @types/smart-fox-server`

# Summary
This package contains type definitions for SmartFoxServer Apis (http://docs2x.smartfoxserver.com/api-docs/jsdoc/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/smart-fox-server

Additional Details
 * Last updated: Wed, 05 Oct 2016 20:53:40 GMT
 * File structure: Global
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: SFS2X

# Credits
These definitions were written by Gregory Moore <https://github.com/ChanceM>.
